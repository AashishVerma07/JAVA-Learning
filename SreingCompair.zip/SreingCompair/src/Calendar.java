public class Calendar {
    public static String monthToString (Month month) {
        return month.toString();
    }
}
